/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.awt.*;
import java.sql.* ; 
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author imaji
 */
public class Connector {
    Connection conn;
    Statement stat;
    ResultSet resultSet;
    PreparedStatement preparedStatement ; 
    private Component rootPane;
    

     public Connector(){   
    try{
            String URL = "jdbc:mysql://b32lxdpqqnq1llu3uvph-mysql.services.clever-cloud.com:3306/b32lxdpqqnq1llu3uvph";
            String username = "Resturant"; // uezi4aavx3gqqeyw
            String pass = "0fFdWV9ZTeCakaMbx6jF";
            
            conn = DriverManager.getConnection(URL, username , pass);
            stat = conn.createStatement();
            System.out.println("Connected");
            fillTable();
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
     }
     
         public void fillTable(){
              
        try {
            String sql = "SELECT * FROM b32lxdpqqnq1llu3uvph";
            resultSet = stat.executeQuery(sql);
            
            DefaultTableModel tblModel;
       //     tblModel = (DefaultTableModel)  // Receipt_takenBy_Cashier.getModel();
         //   tblModel.setRowCount(0);
            
            while(resultSet.next()){
                String BillNo = resultSet.getString("Bill Number");
                String TotalPrice = resultSet.getString("Total");
                String Cashier_id = resultSet.getString("Cashier ID");
               

                String tbData[] = {BillNo,TotalPrice,Cashier_id};
             //   tblModel = (DefaultTableModel) // Receipt_takenBy_Cashier.getModel();

               // tblModel.addRow(tbData);
}
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        
    
         }
     
    
     public void uploadReceipt(Receipt receipt){
            try {
                   
            } catch(Exception e){
                
            }
     }
     
     
     
    
}
