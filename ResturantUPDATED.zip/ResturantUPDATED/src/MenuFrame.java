
import com.mysql.cj.x.protobuf.MysqlxNotice.Warning.Level;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.System.Logger;
import javax.swing.JOptionPane;

public class MenuFrame extends javax.swing.JFrame {
int colaNum , upNum, orangeNum, mojitoNum, friesNum, moltenNum, macNum, shrimpNum, pizzaNum, pastaNum, salmonNum, spaghettiNum; 
double cola_Price, up_Price, mojito_Price, orange_Price, molten_Price, mac_Price, fries_Price, shrimp_Price, pizza_Price,pasta_Price , salmon_Price, spaghetti_Price;
final double colaCost=6.0, upCost=6.0, mojitoCost=14.0, orangeCost=10.0, moltenCost=28.0, macCost=39.0, friesCost=32.0, shrimpCost=42.0, pizzaCost=60.0,pastaCost=52.0, salmonCost=71.0, spaghettiCost=55.0;
double subTotal,vat, total;
int receiptNo=1;
PrintWriter output;

Connector connector = new Connector() ; 

    public MenuFrame() {
        initComponents();
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        DrinksPnl = new javax.swing.JPanel();
        colaLbl = new javax.swing.JLabel();
        upLbl = new javax.swing.JLabel();
        mojitoLbl = new javax.swing.JLabel();
        colaCountS = new javax.swing.JSpinner();
        upCountS = new javax.swing.JSpinner();
        mojitoCountS = new javax.swing.JSpinner();
        orangLbl = new javax.swing.JLabel();
        orangeCountS = new javax.swing.JSpinner();
        orangePriceLbl = new javax.swing.JLabel();
        upPriceLbl = new javax.swing.JLabel();
        colaPriceLbl = new javax.swing.JLabel();
        mojitoPriceLbl = new javax.swing.JLabel();
        AppetizerPnl = new javax.swing.JPanel();
        friesLbl = new javax.swing.JLabel();
        moltenLbl = new javax.swing.JLabel();
        shrimpLbl = new javax.swing.JLabel();
        friesCountS = new javax.swing.JSpinner();
        moltenCountS = new javax.swing.JSpinner();
        shrimpCountS = new javax.swing.JSpinner();
        macLbl = new javax.swing.JLabel();
        macCountS = new javax.swing.JSpinner();
        friesPriceLbl = new javax.swing.JLabel();
        moltenPriceLbl = new javax.swing.JLabel();
        macPriceLbl = new javax.swing.JLabel();
        shrimpPriceLbl = new javax.swing.JLabel();
        MainCoursePnl = new javax.swing.JPanel();
        pizzaLbl = new javax.swing.JLabel();
        pastaLbl = new javax.swing.JLabel();
        spaghettiLbl = new javax.swing.JLabel();
        pizzaCountS = new javax.swing.JSpinner();
        pastaCountS = new javax.swing.JSpinner();
        spaghettiCountS = new javax.swing.JSpinner();
        salmonLbl = new javax.swing.JLabel();
        salmonCountS = new javax.swing.JSpinner();
        pizzaPriceLbl = new javax.swing.JLabel();
        spaghettiPriceLbl = new javax.swing.JLabel();
        salmonPriceLbl = new javax.swing.JLabel();
        pastaPriceLbl = new javax.swing.JLabel();
        spaghettiSpicy = new javax.swing.JCheckBox();
        pizzaSpicy = new javax.swing.JCheckBox();
        pastaChicken = new javax.swing.JCheckBox();
        salmonRice = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        subTotalLbl = new javax.swing.JLabel();
        vatLbl = new javax.swing.JLabel();
        totalLbl = new javax.swing.JLabel();
        receiptNoLbl = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        payBtn = new javax.swing.JButton();
        newReceiptBtn = new javax.swing.JButton();
        saveReceiptBtn = new javax.swing.JButton();
        goBackMenueBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(245, 241, 228));

        jPanel4.setBackground(new java.awt.Color(248, 244, 230));

        jLabel3.setFont(new java.awt.Font("Thonburi", 3, 24)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Screen Shot 1443-09-29 at 4.38.37 PM.png"))); // NOI18N

        DrinksPnl.setBackground(new java.awt.Color(246, 242, 228));
        DrinksPnl.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "DRINKS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Thonburi", 3, 14))); // NOI18N
        DrinksPnl.setPreferredSize(new java.awt.Dimension(260, 278));

        colaLbl.setText("Cola");

        upLbl.setText("7up");

        mojitoLbl.setText("Mojito");

        colaCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        colaCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                colaCountSStateChanged(evt);
            }
        });

        upCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        upCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                upCountSStateChanged(evt);
            }
        });

        mojitoCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        mojitoCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                mojitoCountSStateChanged(evt);
            }
        });

        orangLbl.setText("Orange juice");

        orangeCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        orangeCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                orangeCountSStateChanged(evt);
            }
        });

        orangePriceLbl.setText("0.0 SR");

        upPriceLbl.setText("0.0 SR");

        colaPriceLbl.setText("0.0 SR");

        mojitoPriceLbl.setText("0.0 SR");

        javax.swing.GroupLayout DrinksPnlLayout = new javax.swing.GroupLayout(DrinksPnl);
        DrinksPnl.setLayout(DrinksPnlLayout);
        DrinksPnlLayout.setHorizontalGroup(
            DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DrinksPnlLayout.createSequentialGroup()
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(DrinksPnlLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(DrinksPnlLayout.createSequentialGroup()
                                .addComponent(mojitoLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                                .addComponent(mojitoCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DrinksPnlLayout.createSequentialGroup()
                                .addComponent(upLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(upCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(DrinksPnlLayout.createSequentialGroup()
                                .addComponent(colaLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(colaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(DrinksPnlLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(orangLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(orangeCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 21, Short.MAX_VALUE)
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(colaPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(upPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(orangePriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(mojitoPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        DrinksPnlLayout.setVerticalGroup(
            DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DrinksPnlLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(colaLbl)
                    .addComponent(colaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(colaPriceLbl))
                .addGap(30, 30, 30)
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(upLbl)
                    .addComponent(upCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(upPriceLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orangLbl)
                    .addComponent(orangeCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(orangePriceLbl))
                .addGap(30, 30, 30)
                .addGroup(DrinksPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mojitoLbl)
                    .addComponent(mojitoCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mojitoPriceLbl))
                .addGap(30, 30, 30))
        );

        AppetizerPnl.setBackground(new java.awt.Color(245, 241, 229));
        AppetizerPnl.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "APPETIZERS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Thonburi", 3, 14))); // NOI18N
        AppetizerPnl.setPreferredSize(new java.awt.Dimension(260, 278));

        friesLbl.setText("Truffel Fries");

        moltenLbl.setText("Molten Chocolate");

        shrimpLbl.setText("Dynamite Shrimp");

        friesCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        friesCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                friesCountSStateChanged(evt);
            }
        });

        moltenCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        moltenCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                moltenCountSStateChanged(evt);
            }
        });

        shrimpCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        shrimpCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                shrimpCountSStateChanged(evt);
            }
        });

        macLbl.setText("Mac&Cheese Balls");

        macCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        macCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                macCountSStateChanged(evt);
            }
        });

        friesPriceLbl.setText("0.0 SR");

        moltenPriceLbl.setText("0.0 SR");

        macPriceLbl.setText("0.0 SR");

        shrimpPriceLbl.setText("0.0 SR");

        javax.swing.GroupLayout AppetizerPnlLayout = new javax.swing.GroupLayout(AppetizerPnl);
        AppetizerPnl.setLayout(AppetizerPnlLayout);
        AppetizerPnlLayout.setHorizontalGroup(
            AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AppetizerPnlLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppetizerPnlLayout.createSequentialGroup()
                        .addComponent(shrimpLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(shrimpCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppetizerPnlLayout.createSequentialGroup()
                        .addComponent(moltenLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(moltenCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppetizerPnlLayout.createSequentialGroup()
                        .addComponent(friesLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(friesCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppetizerPnlLayout.createSequentialGroup()
                        .addComponent(macLbl)
                        .addGap(18, 18, 18)
                        .addComponent(macCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(friesPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(shrimpPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(macPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(moltenPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        AppetizerPnlLayout.setVerticalGroup(
            AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AppetizerPnlLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(friesLbl)
                    .addComponent(friesCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(friesPriceLbl))
                .addGap(30, 30, 30)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(moltenLbl)
                    .addComponent(moltenCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(moltenPriceLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(macLbl)
                    .addComponent(macCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(macPriceLbl))
                .addGap(30, 30, 30)
                .addGroup(AppetizerPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(shrimpLbl)
                    .addComponent(shrimpCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(shrimpPriceLbl))
                .addGap(30, 30, 30))
        );

        MainCoursePnl.setBackground(new java.awt.Color(245, 241, 232));
        MainCoursePnl.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "MAIN COURSE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Thonburi", 3, 14))); // NOI18N
        MainCoursePnl.setPreferredSize(new java.awt.Dimension(260, 278));

        pizzaLbl.setText("Buratta Pizza");

        pastaLbl.setText("Pink Pasta");

        spaghettiLbl.setText("Spaghetti");

        pizzaCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        pizzaCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                pizzaCountSStateChanged(evt);
            }
        });

        pastaCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        pastaCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                pastaCountSStateChanged(evt);
            }
        });

        spaghettiCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        spaghettiCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spaghettiCountSStateChanged(evt);
            }
        });

        salmonLbl.setText("Rosemary Salmon");

        salmonCountS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        salmonCountS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                salmonCountSStateChanged(evt);
            }
        });

        pizzaPriceLbl.setText("0.0 SR");

        spaghettiPriceLbl.setText("0.0 SR");

        salmonPriceLbl.setText("0.0 SR");

        pastaPriceLbl.setText("0.0 SR");

        spaghettiSpicy.setText("Spicy");
        spaghettiSpicy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spaghettiSpicyActionPerformed(evt);
            }
        });

        pizzaSpicy.setText("Spicy");
        pizzaSpicy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pizzaSpicyActionPerformed(evt);
            }
        });

        pastaChicken.setText("Chicken");
        pastaChicken.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pastaChickenActionPerformed(evt);
            }
        });

        salmonRice.setText("Rice");
        salmonRice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salmonRiceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MainCoursePnlLayout = new javax.swing.GroupLayout(MainCoursePnl);
        MainCoursePnl.setLayout(MainCoursePnlLayout);
        MainCoursePnlLayout.setHorizontalGroup(
            MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainCoursePnlLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MainCoursePnlLayout.createSequentialGroup()
                        .addComponent(spaghettiLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(spaghettiCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(MainCoursePnlLayout.createSequentialGroup()
                        .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(pastaLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(pizzaLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(salmonLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(MainCoursePnlLayout.createSequentialGroup()
                                .addComponent(salmonCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27))
                            .addGroup(MainCoursePnlLayout.createSequentialGroup()
                                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pizzaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pastaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(11, 11, 11)
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainCoursePnlLayout.createSequentialGroup()
                        .addComponent(pastaChicken)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainCoursePnlLayout.createSequentialGroup()
                        .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spaghettiSpicy)
                            .addComponent(pizzaSpicy)
                            .addComponent(salmonRice))
                        .addGap(31, 31, 31)))
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(spaghettiPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(salmonPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pastaPriceLbl)
                    .addComponent(pizzaPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        MainCoursePnlLayout.setVerticalGroup(
            MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainCoursePnlLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pizzaLbl)
                    .addComponent(pizzaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pizzaPriceLbl)
                    .addComponent(pizzaSpicy))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pastaLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(pastaPriceLbl)
                        .addComponent(pastaChicken)
                        .addComponent(pastaCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MainCoursePnlLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(salmonLbl)
                            .addComponent(salmonCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(salmonRice)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainCoursePnlLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(salmonPriceLbl)))
                .addGap(31, 31, 31)
                .addGroup(MainCoursePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spaghettiLbl)
                    .addComponent(spaghettiCountS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(spaghettiPriceLbl)
                    .addComponent(spaghettiSpicy))
                .addGap(40, 40, 40))
        );

        jPanel1.setBackground(new java.awt.Color(246, 242, 230));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Receipt", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Thonburi", 3, 14))); // NOI18N

        subTotalLbl.setText("SubTotal: 0.0 SR");

        vatLbl.setText("VAT included: 0.0 SR");

        totalLbl.setText("Total: 0.0 SR");

        receiptNoLbl.setText("Receipt No. : 0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(receiptNoLbl))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addComponent(subTotalLbl)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(81, Short.MAX_VALUE)
                .addComponent(vatLbl)
                .addGap(78, 78, 78))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(totalLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(subTotalLbl)
                .addGap(18, 18, 18)
                .addComponent(vatLbl)
                .addGap(18, 18, 18)
                .addComponent(totalLbl)
                .addGap(12, 12, 12)
                .addComponent(receiptNoLbl)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(245, 241, 229));

        payBtn.setBackground(new java.awt.Color(246, 242, 229));
        payBtn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        payBtn.setText("Pay");
        payBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payBtnActionPerformed(evt);
            }
        });

        newReceiptBtn.setBackground(new java.awt.Color(246, 242, 234));
        newReceiptBtn.setText("New Receipt");
        newReceiptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newReceiptBtnActionPerformed(evt);
            }
        });

        saveReceiptBtn.setBackground(new java.awt.Color(248, 242, 233));
        saveReceiptBtn.setText("Save Receipt");
        saveReceiptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveReceiptBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(payBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(newReceiptBtn)
                        .addGap(74, 74, 74))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(saveReceiptBtn)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(payBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(saveReceiptBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(newReceiptBtn)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        goBackMenueBtn.setBackground(new java.awt.Color(246, 244, 236));
        goBackMenueBtn.setText("GO BACK");
        goBackMenueBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goBackMenueBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(DrinksPnl, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(AppetizerPnl, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(MainCoursePnl, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(goBackMenueBtn)))
                .addGap(14, 14, 14))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(358, 358, 358)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(171, 171, 171)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(MainCoursePnl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(DrinksPnl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(AppetizerPnl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(goBackMenueBtn)
                        .addGap(82, 82, 82))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 972, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 689, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void payBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payBtnActionPerformed
       
     
        subTotal=cola_Price+up_Price+ mojito_Price+ orange_Price+ molten_Price+ mac_Price+ fries_Price+ shrimp_Price+ pizza_Price+pasta_Price + salmon_Price+ spaghetti_Price;
        
        subTotalLbl.setText("SubTotal "+subTotal+" SR");
        
        
        vat=subTotal*0.15;
        vatLbl.setText("VAT included "+vat+" SR");
        
        total=subTotal+vat;
        totalLbl.setText("Total "+total+" SR");
        
         if (subTotal==0){
        JOptionPane.showMessageDialog(null,"Please select an item first!",null,JOptionPane.INFORMATION_MESSAGE);
    } else {
          JOptionPane.showMessageDialog(null,"Paid successfully");
            }
    }//GEN-LAST:event_payBtnActionPerformed

    private void colaCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_colaCountSStateChanged
      colaNum =(Integer) colaCountS.getValue();
      cola_Price=colaCost*colaNum;
      colaPriceLbl.setText(cola_Price+ " SR");
      
    }//GEN-LAST:event_colaCountSStateChanged

    private void saveReceiptBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveReceiptBtnActionPerformed
      
        try {

            if (total != 0) {
      
           output = new PrintWriter("billNo." + receiptNo + ".txt");

           
          JOptionPane.showMessageDialog(null, "Recipt number: " + receiptNo + "  has been saved successfuly" + "");
                output.close();
                
            output.println(receiptNo + " Bill number is: ");
                output.println("==============");
                output.println("----");
                output.println("Subtotal is: " + subTotalLbl + " SR");
                output.println("vat: " + vatLbl + " SR");
                output.println("Total is: " + totalLbl + " SR");
                output.println();
                output.println("THANK YOU FOR ORDERING");

   
            }
            
        } catch (FileNotFoundException ex) {
           // Logger.getLogger(Resturant.class.getName()).log(Level.SEVERE, null, ex);

        }

    }//GEN-LAST:event_saveReceiptBtnActionPerformed

    private void upCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_upCountSStateChanged
      upNum =(Integer) upCountS.getValue();
      up_Price=upCost*upNum;
      upPriceLbl.setText(up_Price+ " SR");
      
    }//GEN-LAST:event_upCountSStateChanged

    private void orangeCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_orangeCountSStateChanged
      orangeNum =(Integer) orangeCountS.getValue();
      orange_Price=orangeCost*orangeNum;
      orangePriceLbl.setText(orange_Price+ " SR");
    }//GEN-LAST:event_orangeCountSStateChanged

    private void mojitoCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_mojitoCountSStateChanged
      mojitoNum =(Integer) mojitoCountS.getValue();
      mojito_Price=mojitoCost*mojitoNum;
      mojitoPriceLbl.setText(mojito_Price+ " SR");
    }//GEN-LAST:event_mojitoCountSStateChanged

    private void friesCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_friesCountSStateChanged
      friesNum =(Integer) friesCountS.getValue();
      fries_Price=friesCost*friesNum;
      friesPriceLbl.setText(fries_Price+ " SR");
    }//GEN-LAST:event_friesCountSStateChanged

    private void moltenCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_moltenCountSStateChanged
      moltenNum =(Integer) moltenCountS.getValue();
      molten_Price=moltenCost*moltenNum;
      moltenPriceLbl.setText(molten_Price+ " SR");
    }//GEN-LAST:event_moltenCountSStateChanged

    private void macCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_macCountSStateChanged
      macNum =(Integer) macCountS.getValue();
      mac_Price=macCost*macNum;
      macPriceLbl.setText(mac_Price+ " SR");
    }//GEN-LAST:event_macCountSStateChanged

    private void shrimpCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_shrimpCountSStateChanged
      shrimpNum =(Integer) shrimpCountS.getValue();
      shrimp_Price=shrimpCost*shrimpNum;
      shrimpPriceLbl.setText(shrimp_Price+ " SR");
    }//GEN-LAST:event_shrimpCountSStateChanged

    private void pizzaCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_pizzaCountSStateChanged
      pizzaNum =(Integer) pizzaCountS.getValue();
      pizza_Price=pizzaCost*pizzaNum;
      pizzaPriceLbl.setText(pizza_Price+ " SR");
    }//GEN-LAST:event_pizzaCountSStateChanged

    private void pastaCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_pastaCountSStateChanged
      pastaNum =(Integer) pastaCountS.getValue();
      pasta_Price=pastaCost*pastaNum;
      pastaPriceLbl.setText(pasta_Price+ " SR");
    }//GEN-LAST:event_pastaCountSStateChanged

    private void salmonCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_salmonCountSStateChanged
      salmonNum =(Integer) salmonCountS.getValue();
      salmon_Price=salmonCost*salmonNum;
      salmonPriceLbl.setText(salmon_Price+ " SR");
    }//GEN-LAST:event_salmonCountSStateChanged

    private void spaghettiCountSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spaghettiCountSStateChanged
      spaghettiNum =(Integer) spaghettiCountS.getValue();
      spaghetti_Price=spaghettiCost*spaghettiNum;
      spaghettiPriceLbl.setText(spaghetti_Price+ " SR");
    }//GEN-LAST:event_spaghettiCountSStateChanged

    private void pizzaSpicyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pizzaSpicyActionPerformed
    if(pizzaSpicy.isSelected()){
      pizza_Price+=pizzaNum;  
    }else{
        pizza_Price-=pizzaNum;
    }
    pizzaPriceLbl.setText(pizza_Price+ " SR"); 
    }//GEN-LAST:event_pizzaSpicyActionPerformed

    private void pastaChickenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pastaChickenActionPerformed
     if(pastaChicken.isSelected()){
      pasta_Price+=pastaNum;  
    }else{
        pasta_Price-=pastaNum;
    }
    pastaPriceLbl.setText(pasta_Price+ " SR");    
    }//GEN-LAST:event_pastaChickenActionPerformed

    private void salmonRiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salmonRiceActionPerformed
     if(salmonRice.isSelected()){
      salmon_Price+=salmonNum;  
    }else{
        salmon_Price-=salmonNum;
    }
    salmonPriceLbl.setText(salmon_Price+ " SR");
    }//GEN-LAST:event_salmonRiceActionPerformed

    private void spaghettiSpicyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spaghettiSpicyActionPerformed
     if(spaghettiSpicy.isSelected()){
      spaghetti_Price+=spaghettiNum;  
    }else{
        spaghetti_Price-=spaghettiNum;
    }
    spaghettiPriceLbl.setText(spaghetti_Price+ " SR");
    }//GEN-LAST:event_spaghettiSpicyActionPerformed

    private void newReceiptBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newReceiptBtnActionPerformed
    if (total!=0){
      colaCountS.setValue(0);
      upCountS.setValue(0);
      orangeCountS.setValue(0);
      mojitoCountS.setValue(0);
      
      friesCountS.setValue(0);
      moltenCountS.setValue(0);
      macCountS.setValue(0);
      shrimpCountS.setValue(0);
      
      pizzaCountS.setValue(0);
      pastaCountS.setValue(0);
      salmonCountS.setValue(0);
      spaghettiCountS.setValue(0);
      
      pizzaSpicy.setSelected(false);
      pastaChicken.setSelected(false);
      salmonRice.setSelected(false);
      spaghettiSpicy.setSelected(false);
      
      subTotalLbl.setText("SubTotal : 0.0 SR");
      vatLbl.setText("VAT included : 0.0 SR");
      totalLbl.setText("Total : 0.0 SR");
      
      subTotal=0;
      vat=0;
      total=0;
             
      receiptNo++;
      receiptNoLbl.setText("ReceiptNo. :"+receiptNo);
      
    }
    }//GEN-LAST:event_newReceiptBtnActionPerformed

    private void goBackMenueBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goBackMenueBtnActionPerformed
       this.dispose();
        NewJFrame GoBack = new NewJFrame();
        GoBack.setVisible(true);
    }//GEN-LAST:event_goBackMenueBtnActionPerformed

   
    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AppetizerPnl;
    private javax.swing.JPanel DrinksPnl;
    private javax.swing.JPanel MainCoursePnl;
    private javax.swing.JSpinner colaCountS;
    private javax.swing.JLabel colaLbl;
    private javax.swing.JLabel colaPriceLbl;
    private javax.swing.JSpinner friesCountS;
    private javax.swing.JLabel friesLbl;
    private javax.swing.JLabel friesPriceLbl;
    private javax.swing.JButton goBackMenueBtn;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSpinner macCountS;
    private javax.swing.JLabel macLbl;
    private javax.swing.JLabel macPriceLbl;
    private javax.swing.JSpinner mojitoCountS;
    private javax.swing.JLabel mojitoLbl;
    private javax.swing.JLabel mojitoPriceLbl;
    private javax.swing.JSpinner moltenCountS;
    private javax.swing.JLabel moltenLbl;
    private javax.swing.JLabel moltenPriceLbl;
    private javax.swing.JButton newReceiptBtn;
    private javax.swing.JLabel orangLbl;
    private javax.swing.JSpinner orangeCountS;
    private javax.swing.JLabel orangePriceLbl;
    private javax.swing.JCheckBox pastaChicken;
    private javax.swing.JSpinner pastaCountS;
    private javax.swing.JLabel pastaLbl;
    private javax.swing.JLabel pastaPriceLbl;
    private javax.swing.JButton payBtn;
    private javax.swing.JSpinner pizzaCountS;
    private javax.swing.JLabel pizzaLbl;
    private javax.swing.JLabel pizzaPriceLbl;
    private javax.swing.JCheckBox pizzaSpicy;
    private javax.swing.JLabel receiptNoLbl;
    private javax.swing.JSpinner salmonCountS;
    private javax.swing.JLabel salmonLbl;
    private javax.swing.JLabel salmonPriceLbl;
    private javax.swing.JCheckBox salmonRice;
    private javax.swing.JButton saveReceiptBtn;
    private javax.swing.JSpinner shrimpCountS;
    private javax.swing.JLabel shrimpLbl;
    private javax.swing.JLabel shrimpPriceLbl;
    private javax.swing.JSpinner spaghettiCountS;
    private javax.swing.JLabel spaghettiLbl;
    private javax.swing.JLabel spaghettiPriceLbl;
    private javax.swing.JCheckBox spaghettiSpicy;
    private javax.swing.JLabel subTotalLbl;
    private javax.swing.JLabel totalLbl;
    private javax.swing.JSpinner upCountS;
    private javax.swing.JLabel upLbl;
    private javax.swing.JLabel upPriceLbl;
    private javax.swing.JLabel vatLbl;
    // End of variables declaration//GEN-END:variables
}
